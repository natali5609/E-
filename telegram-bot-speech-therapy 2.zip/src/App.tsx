import React from "react";
import { motion } from "framer-motion";
import { 
  BookOpen, 
  Baby, 
  GraduationCap, 
  Download, 
  ExternalLink, 
  Music, 
  Smile, 
  Flower2,
  Heart,
  CloudSun
} from "lucide-react";

// Types for our product data
interface Product {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  age: string;
  features: string[];
  links: { label: string; url: string; primary?: boolean }[];
  color: string;
  icon: React.ElementType;
  bgGradient: string;
}

const products: Product[] = [
  {
    id: 1,
    title: "Стихи: Непослушный язычок",
    subtitle: "Для запуска речи (PDF)",
    description: "Авторские стихи Алены Васильевой для самых маленьких.",
    age: "0+",
    features: ["Развитие ритма", "Простые рифмы", "PDF формат"],
    links: [
      { label: "Открыть стихи", url: "https://cloud.mail.ru/public/rttC/2tdcQhgoo", primary: true }
    ],
    color: "text-rose-600",
    icon: BookOpen,
    bgGradient: "from-rose-100 to-pink-50"
  },
  {
    id: 2,
    title: "Непослушный язычок",
    subtitle: "Курс 2022 года",
    description: "Программа по запуску речи. Логопедические песни и упражнения.",
    age: "0 - 3 года",
    features: ["16 уроков (по 2-3 мин)", "Логопедические песни", "В любое время"],
    links: [
      { label: "Яндекс Диск", url: "https://disk.yandex.ru/d/h9Ckv2pdskuz6Q", primary: true },
      { label: "Облако Mail.ru", url: "https://cloud.mail.ru/public/GjVy/NfehKsxdt", primary: false }
    ],
    color: "text-blue-600",
    icon: Baby,
    bgGradient: "from-blue-100 to-cyan-50"
  },
  {
    id: 3,
    title: "Маленькие гении",
    subtitle: "Курс 2024 года",
    description: "Изучение звуков алфавита в игровой форме.",
    age: "3 - 6 лет",
    features: ["31 урок (по 5 мин)", "Каждый звук алфавита", "Групповая форма"],
    links: [
      { label: "Смотреть уроки", url: "https://cloud.mail.ru/public/D9UL/HdXXJrwuL", primary: true }
    ],
    color: "text-emerald-600",
    icon: GraduationCap,
    bgGradient: "from-emerald-100 to-green-50"
  }
];

const FloatingIcon = ({ Icon, className, delay }: { Icon: any, className: string, delay: number }) => (
  <motion.div
    initial={{ y: 0, rotate: 0 }}
    animate={{ y: [0, -20, 0], rotate: [0, 10, -10, 0] }}
    transition={{ duration: 5, repeat: Infinity, delay, ease: "easeInOut" }}
    className={`absolute opacity-20 pointer-events-none ${className}`}
  >
    <Icon size={48} />
  </motion.div>
);

export function App() {
  return (
    <div className="min-h-screen bg-[#FFFDF5] text-slate-800 font-sans relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-pink-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-200/30 rounded-full blur-3xl" />
        
        <FloatingIcon Icon={Flower2} className="text-pink-500 top-10 left-10" delay={0} />
        <FloatingIcon Icon={CloudSun} className="text-yellow-500 top-20 right-10" delay={2} />
        <FloatingIcon Icon={Smile} className="text-blue-500 bottom-40 left-5" delay={1} />
        <FloatingIcon Icon={Heart} className="text-red-500 bottom-10 right-20" delay={3} />
        <FloatingIcon Icon={Music} className="text-purple-500 top-1/2 right-5" delay={4} />
      </div>

      <div className="relative z-10 max-w-md mx-auto px-4 py-8 pb-20">
        
        {/* Header */}
        <motion.header 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 space-y-2"
        >
          <div className="inline-block p-3 bg-white rounded-full shadow-md mb-2">
            <span className="text-4xl">👅</span>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-500 to-violet-500 bg-clip-text text-transparent">
            Непослушный язычок
          </h1>
          <p className="text-slate-500 font-medium">@Neposlyshniibot</p>
        </motion.header>

        {/* Welcome Message */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-white/80 backdrop-blur-sm border-2 border-yellow-200 rounded-2xl p-6 text-center shadow-lg mb-8"
        >
          <h2 className="text-2xl font-bold text-slate-800 mb-2">
            Спасибо за покупку !! 🎉
          </h2>
          <p className="text-slate-600">
            Мы рады, что вы с нами! Вот ваши материалы для развития речи.
          </p>
        </motion.div>

        {/* Product Cards */}
        <div className="space-y-6">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.15 }}
              className={`bg-gradient-to-br ${product.bgGradient} rounded-3xl p-6 shadow-md border border-white/50 relative overflow-hidden group`}
            >
              {/* Card Decoration */}
              <div className="absolute top-0 right-0 p-4 opacity-10 transform group-hover:scale-110 transition-transform duration-500">
                 <product.icon size={120} />
              </div>

              <div className="relative z-10">
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 bg-white rounded-2xl shadow-sm ${product.color}`}>
                    <product.icon size={28} />
                  </div>
                  <span className="bg-white/60 backdrop-blur px-3 py-1 rounded-full text-sm font-bold text-slate-700 shadow-sm border border-white/50">
                    {product.age}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-900 mb-1 leading-tight">
                  {product.title}
                </h3>
                <p className={`font-medium mb-3 ${product.color} opacity-90`}>
                  {product.subtitle}
                </p>
                <p className="text-slate-600 text-sm mb-4 leading-relaxed">
                  {product.description}
                </p>

                {/* Features */}
                <ul className="space-y-1 mb-6">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-xs text-slate-600 font-medium">
                      <div className="w-1.5 h-1.5 rounded-full bg-current opacity-50 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* Buttons */}
                <div className="space-y-2">
                  {product.links.map((link, idx) => (
                    <a
                      key={idx}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`
                        flex items-center justify-center w-full py-3 px-4 rounded-xl font-semibold transition-all active:scale-95
                        ${link.primary 
                          ? 'bg-white text-slate-800 shadow-sm hover:shadow-md' 
                          : 'bg-black/5 text-slate-700 hover:bg-black/10'}
                      `}
                    >
                      {link.label}
                      {link.primary ? (
                        <ExternalLink size={16} className="ml-2 opacity-50" />
                      ) : (
                        <Download size={16} className="ml-2 opacity-50" />
                      )}
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12 text-center text-slate-400 text-sm"
        >
          <p>© 2024 Непослушный язычок</p>
          <p className="text-xs mt-1">Развиваемся играя!</p>
        </motion.footer>
      </div>
    </div>
  );
}
